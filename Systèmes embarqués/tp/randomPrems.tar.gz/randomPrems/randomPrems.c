/*
  @author Mickaël THERAUD
*/

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdint.h>

main ()
{
   int i=3, count, c, next=1;

   int myFile = open("/dev/random", O_RDONLY);
   uint16_t n;
   int LeNb = read(myFile, &n, sizeof(n)) ;
   close(myFile);

   n = n % 100;
   printf("Random number is : %d\n",n);

   if ( n >= 1 )
   {
      printf("2\n");
   }

   for ( count = 2 ; count <= n ;  )
   {
      for ( c = 2 ; c <= i - 1 ; c++ )
      {
         if ( i%c == 0 )
           break;
      }
      if ( c == i )
      {
         if(c>n){
	    next = 0;
            break;
         }

         printf("%d\n",i);
         count++;
      }

      i++;

      if(next == 0)
	break;
   }

   printf("Random number is : %d\n",n);

   return 0;

}
