#include <stdio.h>

int main() {
  printf("Display :%s\n", "\xe3\x81\x82");
  return 0;
}
